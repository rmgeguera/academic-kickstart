+++
title = "Publications"

# View.
#   1 = List
#   2 = Compact
#   3 = Card
#   4 = Citation
view = 4

# Optional featured image (relative to `static/img/` folder).
[header]
image = ""
caption = ""
+++

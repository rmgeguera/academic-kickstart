+++
title = "Posts"

# View.
#   1 = List
#   2 = Compact
#   3 = Card
view = 2

# Optional featured image (relative to `static/img/` folder).
[header]
image = ""
caption = ""
+++
